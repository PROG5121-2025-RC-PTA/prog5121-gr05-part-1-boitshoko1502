/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog5121.assignment.pt1;

/**
 *
 * @author RC_Student_lab
 */
public class PROG5121ASSIGNMENTPT1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      package Potjo_ Baholo;

public class Login; 

    // Constructor
    public Login(); {
        // No setup needed here for now
    }

    // Method to check if the username is valid
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
      // Method to check if the username is valid
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Method to check if the password is complex
    public boolean checkPasswordComplexity(String password) {
        String capital = ".*[A-Z].*";   // At least one uppercase
        String small = ".*[a-z].*";     // At least one lowercase
        String digit = ".*\\d.*";       // At least one digit
        String special = ".*[!@#$%^&*(),.?\":{}|<>].*"; // At least one special character
 return password.length() >= 8 &&
               password.matches(capital) &&
               password.matches(small) &&
               password.matches(digit) &&
               password.matches(special);
    }
    
 // Method to check if the phone number is a valid South African number
    public boolean checkCellPhoneNumber(String phone) {
        String saCode = "+27";
        if (phone.length() == 12 && phone.startsWith(saCode)) {
            char fourthDigitChar = phone.charAt(3);
            int fourthDigit = Character.getNumericValue(fourthDigitChar);
            return fourthDigit >= 6 && fourthDigit <= 8;
        }
        return false;
    }
    }
    
   // Method to register the user
    public String registerUser(String username, String password, String phone) {
        boolean validatePhone = checkCellPhoneNumber(phone);
        boolean validateUsername = checkUserName(username);
        boolean validatePassword = checkPasswordComplexity(password);

        if (validatePhone && validateUsername && validatePassword); {
            return "User is successfully registered.";
         else} 
            return "User registration failed!";
}

    // Method to login user based on validation
    public boolean loginUser(String username, String password) {
        boolean validateUsername = checkUserName(username);
        boolean validatePassword = checkPasswordComplexity(password);

        return validateUsername && validatePassword;
    

 // Method to return login status as a message
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "A successful login.";
        else
            return "A failed login.";
        
    
}

package LoginSystem;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String firstname, lastname, username, password, phone;

        // Prompt and receive user inputs
        System.out.println("------------------------------");
        System.out.println("-----------Register-----------");
        System.out.println("------------------------------");

  System.out.print("Enter First Name: ");
        firstname = input.nextLine();

        System.out.print("Enter Last Name: ");
        lastname = input.nextLine();

        System.out.print("Enter username: ");
        username = input.nextLine();

        System.out.print("Enter Password: ");
        password = input.nextLine();
        
 System.out.print("Enter Phone Number (starting with South African international code (+27)): ");
        phone = input.nextLine();

        Login login = new Login(); // Instantiate Login object

        boolean validatePhone = login.checkCellPhoneNumber(phone);
        boolean validateUsername = login.checkUserName(username);
        boolean validatePassword = login.checkPasswordComplexity(password);

 // Check and validate username
        if (validateUsername) {
            System.out.println("Username successfully captured.");
        } else {
            System.out.println("Username is not correctly formatted. Please ensure that your username contains an underscore and is not more than five characters in length.");
        }
 // Check and validate password
        if (validatePassword) {
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password is incorrect. Please ensure that the password contains at least eight characters, a capital and small letter, a number, and a special character.");
        }
        
  // Check and validate phone number
        if (validatePhone) {
            System.out.println("Cellphone number successfully added.");
        } else {
            System.out.println("Cellphone number is incorrectly formatted or does not contain the international code.");
        }

        // If all validations pass, continue to login
        if (validateUsername && validatePassword && validatePhone) {
            System.out.println("You have registered successfully!");

            String loginUsername;
            String loginPassword;
        
  System.out.println("------------------------------");
            System.out.println("-------------LOGIN------------");
            System.out.println("------------------------------");

            System.out.print("Enter username: ");
            loginUsername = input.nextLine();

            System.out.print("Enter password: ");
            loginPassword = input.nextLine();

            if (loginUsername.equals(username) && loginPassword.equals(password)) {
                System.out.println("Welcome " + firstname + " " + lastname + ", it is great to see you again.");
            } else {
                System.out.println("Login failed! Wrong username or password.");
                
 } else {
            System.out.println("Failed to register.");
        }

        input.close(); // Always good practice to close the scanner
    }
}